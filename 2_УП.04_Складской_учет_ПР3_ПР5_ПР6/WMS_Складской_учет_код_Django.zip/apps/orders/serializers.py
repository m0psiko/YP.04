from rest_framework import serializers
from .models import Order, OrderItem
from apps.catalog.serializers import ModelSerializer

class OrderItemSerializer(serializers.ModelSerializer):
    item_details = ModelSerializer(source='item', read_only=True)

    class Meta:
        model = OrderItem
        fields = ['id', 'item', 'item_details', 'quantity', 'price']

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    client_name = serializers.ReadOnlyField(source='client.name')
    author_name = serializers.ReadOnlyField(source='author.full_name')

    class Meta:
        model = Order
        fields = '__all__'
