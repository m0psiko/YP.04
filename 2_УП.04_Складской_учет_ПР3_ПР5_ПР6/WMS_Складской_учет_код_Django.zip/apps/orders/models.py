from django.db import models
from django.conf import settings
from apps.clients.models import Client
from apps.catalog.models import Model, Location

class Order(models.Model):
    class OrderType(models.TextChoices):
        INCOME = 'income', 'Приходная накладная (Поступление)'
        OUTCOME = 'outcome', 'Расходная накладная (Отгрузка)'
        MOVE = 'move', 'Внутреннее перемещение'

    class Status(models.TextChoices):
        DRAFT = 'draft', 'Черновик'
        RESERVED = 'reserved', 'Зарезервировано'
        COMPLETED = 'completed', 'Проведено'
        CANCELLED = 'cancelled', 'Аннулировано'

    order_number = models.CharField('Номер накладной', max_length=64, unique=True)
    order_type = models.CharField('Тип операции', max_length=32, choices=OrderType.choices, default=OrderType.OUTCOME)
    status = models.CharField('Статус накладной', max_length=32, choices=Status.choices, default=Status.DRAFT)
    client = models.ForeignKey(Client, on_delete=models.PROTECT, verbose_name='Контрагент / Получатель', null=True, blank=True)
    source_location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name='outgoing_orders', verbose_name='Склад-отправитель', null=True, blank=True)
    target_location = models.ForeignKey(Location, on_delete=models.PROTECT, related_name='incoming_orders', verbose_name='Склад-получатель', null=True, blank=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, verbose_name='Сотрудник (МОЛ)')
    comment = models.TextField('Примечание / Обоснование', blank=True)
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    completed_at = models.DateTimeField('Дата проведения', null=True, blank=True)

    class Meta:
        verbose_name = 'Складская накладная'
        verbose_name_plural = 'Складские накладные'
        ordering = ['-created_at']

    def __str__(self):
        return f"№ {self.order_number} ({self.get_order_type_display()}) — {self.get_status_display()}"

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items', verbose_name='Накладная')
    item = models.ForeignKey(Model, on_delete=models.PROTECT, verbose_name='Номенклатура ТМЦ')
    quantity = models.PositiveIntegerField('Количество', default=1)
    price = models.DecimalField('Учетная цена за ед. (руб.)', max_digits=12, decimal_places=2, default=0.0)

    class Meta:
        verbose_name = 'Позиция накладной'
        verbose_name_plural = 'Позиции накладной'

    def __str__(self):
        return f"{self.item.name} — {self.quantity} шт."
