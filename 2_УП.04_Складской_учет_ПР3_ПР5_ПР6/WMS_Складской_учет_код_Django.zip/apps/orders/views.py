from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from .models import Order, OrderItem
from .serializers import OrderSerializer, OrderItemSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.prefetch_related('items__item').select_related('client', 'author').all()
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]
    filterset_fields = ['status', 'order_type', 'client']
    search_fields = ['order_number', 'comment']

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        order = self.get_object()
        if order.status == Order.Status.COMPLETED:
            return Response({'error': 'Накладная уже проведена'}, status=status.HTTP_400_BAD_REQUEST)
        order.status = Order.Status.COMPLETED
        order.completed_at = timezone.now()
        order.save()
        return Response({'status': 'Накладная успешно проведена', 'completed_at': order.completed_at})

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        order = self.get_object()
        order.status = Order.Status.CANCELLED
        order.save()
        return Response({'status': 'Накладная аннулирована'})
