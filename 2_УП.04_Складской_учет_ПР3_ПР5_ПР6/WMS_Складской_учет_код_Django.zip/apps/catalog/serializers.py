from rest_framework import serializers
from .models import Location, Category, Vendor, Model

class LocationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Location
        fields = '__all__'

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = '__all__'

class VendorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vendor
        fields = '__all__'

class ModelSerializer(serializers.ModelSerializer):
    vendor_name = serializers.ReadOnlyField(source='vendor.name')
    category_name = serializers.ReadOnlyField(source='category.name')

    class Meta:
        model = Model
        fields = ['id', 'name', 'vendor', 'vendor_name', 'category', 'category_name']
