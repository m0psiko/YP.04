from rest_framework.routers import DefaultRouter
from .views import LocationViewSet, CategoryViewSet, VendorViewSet, ModelViewSet

router = DefaultRouter()
router.register(r'locations', LocationViewSet)
router.register(r'categories', CategoryViewSet)
router.register(r'vendors', VendorViewSet)
router.register(r'items', ModelViewSet, basename='items')

urlpatterns = router.urls
