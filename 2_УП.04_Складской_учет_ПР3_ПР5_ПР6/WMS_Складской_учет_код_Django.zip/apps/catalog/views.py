from rest_framework import viewsets, permissions
from .models import Location, Category, Vendor, Model
from .serializers import LocationSerializer, CategorySerializer, VendorSerializer, ModelSerializer

class LocationViewSet(viewsets.ModelViewSet):
    queryset = Location.objects.all()
    serializer_class = LocationSerializer
    permission_classes = [permissions.IsAuthenticated]

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [permissions.IsAuthenticated]

class VendorViewSet(viewsets.ModelViewSet):
    queryset = Vendor.objects.all()
    serializer_class = VendorSerializer
    permission_classes = [permissions.IsAuthenticated]

class ModelViewSet(viewsets.ModelViewSet):
    queryset = Model.objects.select_related('vendor', 'category').all()
    serializer_class = ModelSerializer
    permission_classes = [permissions.IsAuthenticated]
    filterset_fields = ['vendor', 'category']
    search_fields = ['name']
