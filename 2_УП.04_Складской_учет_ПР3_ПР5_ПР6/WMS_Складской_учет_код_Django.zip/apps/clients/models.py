from django.db import models

class Client(models.Model):
    class ClientType(models.TextChoices):
        SUPPLIER = 'supplier', 'Поставщик'
        CUSTOMER = 'customer', 'Заказчик / Получатель'
        CONTRACTOR = 'contractor', 'Подрядчик'

    name = models.CharField('Наименование организации / ФИО', max_length=255)
    client_type = models.CharField('Тип контрагента', max_length=32, choices=ClientType.choices, default=ClientType.CUSTOMER)
    inn = models.CharField('ИНН', max_length=12, blank=True)
    phone = models.CharField('Контактный телефон', max_length=32, blank=True)
    email = models.EmailField('Электронная почта', blank=True)
    address = models.TextField('Фактический адрес', blank=True)
    created_at = models.DateTimeField('Дата регистрации', auto_now_add=True)

    class Meta:
        verbose_name = 'Контрагент'
        verbose_name_plural = 'Контрагенты'
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} ({self.get_client_type_display()})"
