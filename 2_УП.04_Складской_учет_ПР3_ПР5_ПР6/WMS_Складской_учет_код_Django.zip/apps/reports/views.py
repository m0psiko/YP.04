from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import permissions
from .services import get_warehouse_kpi

class WarehouseKPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        data = get_warehouse_kpi()
        return Response(data)
