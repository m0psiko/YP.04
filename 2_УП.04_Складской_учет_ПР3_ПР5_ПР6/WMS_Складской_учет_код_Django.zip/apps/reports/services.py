from django.db.models import Sum, Count
from apps.catalog.models import Model, Location, Category
from apps.orders.models import Order, OrderItem
from apps.clients.models import Client

def get_warehouse_kpi():
    total_items = Model.objects.count()
    total_locations = Location.objects.count()
    total_clients = Client.objects.count()
    total_orders = Order.objects.count()
    completed_orders = Order.objects.filter(status=Order.Status.COMPLETED).count()
    total_volume_shipped = OrderItem.objects.filter(order__status=Order.Status.COMPLETED).aggregate(s=Sum('quantity'))['s'] or 0
    total_inventory_value = OrderItem.objects.aggregate(v=Sum('price'))['v'] or 0

    return {
        'total_sku_count': total_items,
        'total_locations': total_locations,
        'total_clients': total_clients,
        'total_orders': total_orders,
        'completed_orders_ratio': round((completed_orders / total_orders * 100), 1) if total_orders > 0 else 100.0,
        'total_units_shipped': total_volume_shipped,
        'total_inventory_value_rub': float(total_inventory_value),
        'system_status': 'ONLINE',
    }
