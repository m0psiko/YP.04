from django.urls import path
from .views import WarehouseKPIView

urlpatterns = [
    path('kpi/', WarehouseKPIView.as_view(), name='warehouse_kpi'),
]
