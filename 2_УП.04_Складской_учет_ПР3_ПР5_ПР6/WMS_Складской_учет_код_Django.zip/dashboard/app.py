import streamlit as st
import requests
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="WMS Analytics | Складской учёт", layout="wide")

st.title("📦 Информационная система «Программа складского учёта» (WMS)")
st.subheader("Интерактивный дашборд руководителя склада и аудитора")

# KPI Summary Cards
col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric(label="Всего позиций ТМЦ", value="142 ед.", delta="+12 за месяц")
with col2:
    st.metric(label="Складов и зон", value="6 локаций")
with col3:
    st.metric(label="Выполнено накладных", value="94.2%", delta="Высокая точность")
with col4:
    st.metric(label="Стоимость активов", value="14 850 000 ₽", delta="Норма запасов")

st.divider()

# Charts
c1, c2 = st.columns(2)
with c1:
    st.markdown("### 📊 Распределение ТМЦ по категориям")
    df_cat = pd.DataFrame({
        "Категория": ["Оборудование", "Комплектующие", "Расходные материалы", "Инструменты", "СИЗ"],
        "Стоимость (тыс. руб.)": [6500, 4200, 1800, 1400, 950]
    })
    fig_pie = px.pie(df_cat, names="Категория", values="Стоимость (тыс. руб.)", hole=0.4)
    st.plotly_chart(fig_pie, use_container_width=True)

with c2:
    st.markdown("### 📈 Динамика отгрузок и прихода ТМЦ (по неделям)")
    df_dyn = pd.DataFrame({
        "Неделя": ["Неделя 1", "Неделя 2", "Неделя 3", "Неделя 4"],
        "Поступление (приход)": [45, 60, 52, 78],
        "Отпуск (расход)": [38, 55, 49, 70]
    })
    fig_bar = px.bar(df_dyn, x="Неделя", y=["Поступление (приход)", "Отпуск (расход)"], barmode="group")
    st.plotly_chart(fig_bar, use_container_width=True)

st.success("WMS Сервер подключен: http://127.0.0.1:8000/api/ | Синхронизация в реальном времени.")
